package com.example.selfieintruso

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.os.UserHandle
import android.util.Log
import androidx.core.content.ContextCompat

class IntruderAdminReceiver : DeviceAdminReceiver() {

    // Se llama cuando el usuario falla al desbloquear con PIN, patrón o contraseña.
    override fun onPasswordFailed(context: Context, intent: Intent, user: UserHandle) {
        super.onPasswordFailed(context, intent, user)

        // Camino rápido: el servicio ya está activo (lo deja corriendo la app al abrirla).
        val service = CaptureService.instance
        if (service != null) {
            service.capture()
            return
        }

        // Respaldo: intentar arrancarlo en frío.
        try {
            ContextCompat.startForegroundService(
                context,
                Intent(context, CaptureService::class.java).putExtra("capture", true)
            )
        } catch (e: Exception) {
            Log.e("IntruderAdmin", "No se pudo iniciar CaptureService", e)
        }
    }
}
