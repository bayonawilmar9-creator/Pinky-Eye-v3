package com.example.selfieintruso

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {

    private val BG = 0xFF0B0B12.toInt()
    private val CARD = 0xFF161622.toInt()
    private val PINK = 0xFFFF2E93.toInt()
    private val TEXT = 0xFFF2F2F7.toInt()
    private val MUTED = 0xFF8E8EA0.toInt()
    private val OK = 0xFF3DDC84.toInt()

    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(BG)

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            clipToPadding = false
            addView(content)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------- Pantalla ----------

    private fun refresh() {
        content.removeAllViews()

        val cam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val dpm = getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(this, IntruderAdminReceiver::class.java)
        val adminOn = dpm.isAdminActive(admin)
        val ready = cam && adminOn

        // Deja el servicio activo para que la foto salga desde el primer intento fallido.
        if (ready && CaptureService.instance == null) {
            try {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, CaptureService::class.java).putExtra("persistent", true)
                )
            } catch (e: Exception) {
                // Si el sistema no lo permite, el receptor usa su camino de respaldo.
            }
        }

        content.addView(tv("PINKY EYE", 30f, PINK, true).apply { letterSpacing = 0.12f })
        content.addView(tv("Foto al fallar el desbloqueo", 14f, MUTED))
        content.addView(gap(20))

        val status = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg(0x66FF2E93)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        status.addView(statusRow("Permiso de cámara", cam))
        status.addView(gap(8))
        status.addView(statusRow("Detección de intentos fallidos", adminOn))
        status.addView(gap(10))
        status.addView(
            tv(
                if (ready) "Protección activa" else "Falta completar la configuración",
                13f, if (ready) OK else MUTED
            )
        )
        content.addView(status)

        if (!cam) {
            content.addView(pinkButton("Permitir cámara y notificaciones", true) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS),
                    1
                )
            })
        }
        if (!adminOn) {
            content.addView(pinkButton("Activar detección", cam) {
                startActivity(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                        .putExtra(
                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Necesario para detectar intentos fallidos de desbloqueo."
                        )
                )
            })
        }

        content.addView(gap(28))
        val files = File(filesDir, "intrusos").listFiles()
            ?.sortedByDescending { it.lastModified() }.orEmpty()
        content.addView(tv("Intentos registrados (${files.size})", 16f, TEXT, true))
        if (files.isEmpty()) {
            content.addView(gap(8))
            content.addView(
                tv("Todavía no hay fotos. Falla el PIN o patrón a propósito para probar.", 14f, MUTED)
            )
        }
        files.forEach { f ->
            content.addView(gap(12))
            content.addView(photoCard(f))
        }
    }

    private fun photoCard(f: File): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg()
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val img = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageBitmap(loadBitmap(f))
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            clipToOutline = true
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        val date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
            .format(Date(f.lastModified()))
        row.addView(
            tv(date, 14f, TEXT),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(tv("Eliminar", 14f, PINK, true).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener {
                f.delete()
                refresh()
            }
        })
        box.addView(img)
        box.addView(row)
        return box
    }

    // ---------- Utilidades de diseño ----------

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun gap(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun cardBg(stroke: Int = 0x33FFFFFF) = GradientDrawable().apply {
        setColor(CARD)
        cornerRadius = dp(16).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun statusRow(label: String, ok: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(tv(if (ok) "✓" else "✕", 18f, if (ok) OK else PINK, true).apply {
            setPadding(0, 0, dp(12), 0)
        })
        addView(tv(label, 15f, TEXT))
    }

    private fun pinkButton(label: String, filled: Boolean, onClick: () -> Unit) =
        Button(this).apply {
            text = label
            setAllCaps(false)
            textSize = 16f
            setTextColor(if (filled) BG else PINK)
            stateListAnimator = null
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                if (filled) {
                    setColor(PINK)
                } else {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), PINK)
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
            ).apply { topMargin = dp(12) }
            setOnClickListener { onClick() }
        }

    private fun loadBitmap(f: File): Bitmap? {
        val bmp = BitmapFactory.decodeFile(
            f.path, BitmapFactory.Options().apply { inSampleSize = 4 }
        ) ?: return null
        val deg = try {
            when (ExifInterface(f.path).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        if (deg == 0f) return bmp
        return Bitmap.createBitmap(
            bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true
        )
    }
}
