package com.example.selfieintruso

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CaptureService : LifecycleService() {

    companion object {
        // Mientras el servicio vive, el receptor lo llama directo (sin arrancar nada en frío).
        @Volatile
        var instance: CaptureService? = null
    }

    private var persistent = false
    private var busy = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Calienta CameraX para que la primera foto salga rápido.
        ProcessCameraProvider.getInstance(this)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.getBooleanExtra("persistent", false) == true) persistent = true
        try {
            startAsForeground()
        } catch (e: Exception) {
            Log.e("CaptureService", "Fallo al iniciar", e)
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.getBooleanExtra("capture", false) == true) capture()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val channelId = "captura"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(channelId, "Captura", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Protección activa")
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )
    }

    fun capture() {
        if (busy) return
        busy = true
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, imageCapture)

                // Pequeña espera para que la cámara ajuste exposición.
                Handler(Looper.getMainLooper()).postDelayed({
                    val dir = File(filesDir, "intrusos").apply { mkdirs() }
                    val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val file = File(dir, "intento_$name.jpg")
                    imageCapture.takePicture(
                        ImageCapture.OutputFileOptions.Builder(file).build(),
                        ContextCompat.getMainExecutor(this),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(r: ImageCapture.OutputFileResults) =
                                finishCapture(provider)

                            override fun onError(e: ImageCaptureException) {
                                Log.e("CaptureService", "Error al capturar", e)
                                finishCapture(provider)
                            }
                        }
                    )
                }, 600)
            } catch (e: Exception) {
                Log.e("CaptureService", "Error con la cámara", e)
                finishCapture(null)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun finishCapture(provider: ProcessCameraProvider?) {
        try {
            provider?.unbindAll()
        } catch (e: Exception) {
            Log.e("CaptureService", "Error al liberar la cámara", e)
        }
        busy = false
        if (!persistent) stopSelf()
    }
}
